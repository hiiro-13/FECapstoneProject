module.exports = {
  mode: "jit",
  purge: ["./index.html", "./src/**/*.{vue,js}"],
  darkMode: false,
  theme: {
    extend: {},
  },
  variants: {},
  plugins: [],
};
