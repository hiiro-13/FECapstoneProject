<template>
  <footer>
    <div class="container">
      <div class="">
        <p class="text-3xl pt-3 font-bold text-white">EGO CLINIC</p>
        <div class="container">
          <div class="row justify-content-between text-white">
            <div class="col-md-3 mt-3 ms-4">
              <p class="text-2xl font-semibold text-white">Contact:</p>
              <p>
                <i
                  class="fa-solid fa-map-location me-2"
                  style="color: #757575"
                ></i>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,
                eveniet!
              </p>
              <p>
                <i class="fa-solid fa-phone me-2" style="color: #757575"></i>
                Hotline: 123456789
              </p>
              <p>
                <i class="fa-solid fa-globe me-2" style="color: #757575"></i>
                www.EgoClinic.com
              </p>
              <p>
                <i
                  class="fa-regular fa-envelope me-2"
                  style="color: #757575"
                ></i
                >egoclinic@gmail.com
              </p>
            </div>
            <div class="col-md-3 mt-3 ms-4">
              <p class="text-2xl font-semibold text-white">Support:</p>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel,
                eveniet!
              </p>
              <p>Hotline: 123456789</p>
              <p>www.EgoClinic.com</p>
              <p>egoclinic@gmail.com</p>
            </div>
            <div class="col-md-3 mt-3 ms-4">
              <p class="text-2xl font-semibold text-white">Work Time:</p>
              <p>
                <i class="fa-solid fa-clock me-2" style="color: #757575"></i
                >Monday to Thursday
              </p>
              <p>
                <i class="fa-solid fa-clock me-2" style="color: #757575"></i
                >Morning: 8am to 11am
              </p>
              <p>
                <i class="fa-solid fa-clock me-2" style="color: #757575"></i
                >Afternoon: 1pm to 5pm
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>
