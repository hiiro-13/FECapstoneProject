export const PUBLIC_LAYOUT = "default";
